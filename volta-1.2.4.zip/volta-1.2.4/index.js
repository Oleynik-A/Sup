// Dependencies
require('babel-core/register');

// Utilities
const path = require('path');

// Environment
const development = process.env.NODE_ENV !== 'production';
const pages = require(path.join(__dirname, 'config', 'pages.config.js'));
const route = require(path.join(__dirname, 'helpers', 'routes.js'));

// Application
const app = new (require('koa'))();
const router = new (require('koa-router'))();
const serve = require('koa-static');
const views = require('koa-views');

// Configuration
const paths = {
  root: path.join(__dirname, (development ? 'build' : 'dist')),
  config: path.join(__dirname, 'config', 'env', (development ? 'development.js' : 'production.js'))
};
const config = require(paths['config']);

// Development Logger
if (development) {
  app.use(async function (ctx, next) {
    const start = new Date();
    await next();
    const ms = new Date() - start;
    console.log(`${ctx.method} ${ctx.url} - ${ms}ms`);
  });
}

route(router, pages, []);

app.use(views(paths['root'], config.server.views));
app.use(serve(paths['root']));
app.use(router.routes());
app.use(router.allowedMethods());

router.get('/', async function(ctx) {
  ctx.redirect(config.server.url + '/dashboard');
  ctx.status = 301;
});

app.listen(config.server.port);
console.info('==> 🌎 Listening on port %s. Open up %s/ in your browser.', config.server.port, config.server.url);
