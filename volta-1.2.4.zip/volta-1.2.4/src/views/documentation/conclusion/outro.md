# Thank you!
As you can see, __we have put a huge amount of work into Volta__ to make it the best available admin template on the market. Our aim was to make a beautiful and intuitive admin template, suited for both beginner and advanced developers, to have a smooth learning curve and to be explained thoroughly so that everyone will understand it.

We must say, you're awesome for choosing and purchasing Volta. <strong>Thank you and stay creative!</strong>
