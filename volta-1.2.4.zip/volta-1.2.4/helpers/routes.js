function getRoutes (router, pages, parents) {
  'use strict';

  for (let index in pages) {
    var page = pages[index];

    if (page.hasOwnProperty('view')) {
      var parentRoute = parents.map(function(page){
        return page['route'];
      }).join('');

      let route = parentRoute + page['route'],
          viewPath = page.view.splice(2),
          renderFile = viewPath.join('-');

      router.get(route, async function(ctx) {
        await ctx.render(renderFile);
      });
    }

    if (page.hasOwnProperty('pages')) {
      getRoutes(router, page['pages'], parents.concat([page]));
    }
  }
};

module.exports = getRoutes;
